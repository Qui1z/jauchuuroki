#include "game_manager.h"
#include "connect4.h"
#include "ball_sort_puzzle.h"

int main() {
    GameManager manager;
    initializeGameManager(&manager);

    Connect4* connect4Game = malloc(sizeof(Connect4));
    initializeConnect4(connect4Game, 6, 7);
    addGame(&manager, (Game*)connect4Game);

    BallSortPuzzle* ballSortPuzzleGame = malloc(sizeof(BallSortPuzzle));
    // addGame(&manager, (Game *)ballSortPuzzleGame);

    runGames(&manager);

    freeGameManager(&manager);
    return 0;
}
