﻿#include "connect4.h"
#include <stdio.h>
#include <stdlib.h>

void initializeConnect4(Connect4* game, int rows, int cols) {
    game->rows = rows;
    game->cols = cols;
    game->currentPlayer = PLAYER_1;

    game->board = malloc(rows * sizeof(char*));
    if (game->board == NULL) {
        printf("Memory allocation error.\n");
        exit(1);
    }

    for (int i = 0; i < rows; i++) {
        game->board[i] = malloc(cols * sizeof(char));
        if (game->board[i] == NULL) {
            printf("Memory allocation error.\n");
            exit(1);
        }
    }

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            game->board[i][j] = BLANK;
        }
    }
}

void printBoard(const Connect4* game) {
    for (int i = 0; i < game->rows; i++) {
        for (int j = 0; j < game->cols; j++) {
            printf("| %c ", game->board[i][j]);
        }
        printf("|\n");

        for (int j = 0; j < game->cols; j++) {
            printf("----");
        }
        printf("\n");
    }

    for (int j = 0; j < game->cols; j++) {
        printf("  %d ", j);
    }
    printf("\n");
}

int makeMove(Connect4* game, int col) {
    for (int i = game->rows - 1; i >= 0; --i) {
        if (game->board[i][col] == BLANK) {
            game->board[i][col] = game->currentPlayer;
            return checkWin(game, i, col);
        }
    }
    return 0;
}

int checkWin(const Connect4* game, int row, int col) {
    int count = 0;

    count = 0;
    for (int i = row; i < game->rows; i++) {
        if (game->board[i][col] == game->currentPlayer) {
            count++;
            if (count >= STRIKE) return 1;
        }
        else {
            break;
        }
    }


    count = 0;
    for (int j = 0; j < game->cols; j++) {
        if (game->board[row][j] == game->currentPlayer) {
            count++;
            if (count >= STRIKE) return 1;
        }
        else {
            break;
        }
    }

    count = 0;
    int startRow = row;
    int startCol = col;
    while (startRow > 0 && startCol > 0) {
        startRow--;
        startCol--;
    }



    for (int i = startRow, j = startCol; i < game->rows && j < game->cols; i++, j++) {
        if (game->board[i][j] == game->currentPlayer) {
            count++;
            if (count >= STRIKE) return 1;
        }
        else {
            break;
        }
    }

    count = 0;

    startRow = row;
    startCol = col;


    while (startRow > 0 && startCol < game->cols - 1) {
        startRow--;
        startCol++;
    }
    for (int i = startRow, j = startCol; i < game->rows && j >= 0; i++, j--) {
        if (game->board[i][j] == game->currentPlayer) {
            count++;
            if (count >= STRIKE) return 1;
        }
        else {
            break;
        }
    }

    return 0;
}

void runConnect4(Connect4* game) {
    int move;
    while (1) {
        printBoard(game);

        printf("Player %c, enter your move (0-%d): ", game->currentPlayer, game->cols - 1);
        if (scanf("%d", &move) != 1 || move < 0 || move >= game->cols) {
            printf("Invalid move. Try again.\n");
            continue;
        }

        if (makeMove(game, move)) {
            printBoard(game);
            printf("Player %c wins!\n", game->currentPlayer);
            return;
        }

        game->currentPlayer = (game->currentPlayer == PLAYER_1) ? PLAYER_2 : PLAYER_1;
    }
}
