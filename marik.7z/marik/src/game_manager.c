#include "game_manager.h"
#include <stdlib.h>

void initializeGameManager(GameManager* manager) {
    manager->games = NULL;
    manager->gameCount = 0;
}

void freeGameManager(GameManager* manager) {
    for (int i = 0; i < manager->gameCount; i++) {
        free(manager->games[i]);
    }
    free(manager->games);
}

void addGame(GameManager* manager, Game* game) {
    manager->games = realloc(manager->games, (manager->gameCount + 1) * sizeof(Game*));
    manager->games[manager->gameCount] = game;
    manager->gameCount++;
}

void runGames(const GameManager* manager) {
    for (int i = 0; i < manager->gameCount; i++) {
        manager->games[i]->initialize(manager->games[i]);
        manager->games[i]->run(manager->games[i]);
    }
}
