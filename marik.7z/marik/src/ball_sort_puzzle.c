#include "ball_sort_puzzle.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void initializeBallSortPuzzle(BallSortPuzzle* puzzle, int rows, int columns) {
    puzzle->rows = rows;
    puzzle->columns = columns;
    puzzle->emptyColumnsCount = EMPTY_COLUMNS;

    puzzle->field = malloc(rows * sizeof(char*));
    for (int i = 0; i < rows; i++) {
        puzzle->field[i] = malloc(columns * sizeof(char));
    }

    puzzle->emptyColumns = malloc(EMPTY_COLUMNS * sizeof(int));

    generateField(puzzle);
}

void freeBallSortPuzzle(BallSortPuzzle* puzzle) {
    for (int i = 0; i < puzzle->rows; i++) {
        free(puzzle->field[i]);
    }
    free(puzzle->field);
    free(puzzle->emptyColumns);
}

void generateField(BallSortPuzzle* puzzle) {
    puzzle->emptyColumns[0] = randomRange(0, puzzle->columns);
    int randomSecond = randomRange(0, puzzle->columns - 1);
    puzzle->emptyColumns[1] = (randomSecond < puzzle->emptyColumns[0]) ? randomSecond : randomSecond + 1;

    for (int i = 0; i < puzzle->rows; i++) {
        for (int j = 0; j < puzzle->columns; j++) {
            puzzle->field[i][j] = BLANK;
        }
    }

    int symbolsSize = (puzzle->columns - EMPTY_COLUMNS) * puzzle->rows;
    int symbolsAvailable[symbolsSize];
    for (int i = 0; i < symbolsSize; i++) {
        symbolsAvailable[i] = 1;
    }

    int excludedCount = 0;
    for (int j = 0; j < puzzle->columns; j++) {
        if (j == puzzle->emptyColumns[0] || j == puzzle->emptyColumns[1]) {
            continue;
        }

        for (int i = 0; i < puzzle->rows; i++) {
            int index = randomIndex(symbolsSize - excludedCount);
            symbolsAvailable[index] = 0;
            excludedCount++;

            puzzle->field[i][j] = SYMBOLS_ORIGIN + index / puzzle->rows;
        }
    }
}

void printField(const BallSortPuzzle* puzzle) {
    for (int i = 0; i < puzzle->rows; i++) {
        printf("%d |", i + 1);
        for (int j = 0; j < puzzle->columns; j++) {
            char cell = puzzle->field[i][j];
            printf(" %c |", cell);
        }
        printf("\n");
    }

    printf("   ");
    for (int j = 0; j < puzzle->columns; j++) {
        printf("+---");
    }
    printf("+\n   ");
    for (int j = 0; j < puzzle->columns; j++) {
        printf(" %d  ", j + 1);
    }
    printf("\n");
}

int checkWin(const BallSortPuzzle* puzzle) {
    for (int j = 0; j < puzzle->columns; j++) {
        if (j == puzzle->emptyColumns[0] || j == puzzle->emptyColumns[1]) {
            continue;
        }

        char symbol = puzzle->field[0][j];
        for (int i = 1; i < puzzle->rows; i++) {
            if (puzzle->field[i][j] != symbol) {
                return 0;
            }
        }
    }
    return 1;
}

int moveBall(BallSortPuzzle* puzzle, int from, int to) {
    if (from < 1 || to < 1 || from > puzzle->columns || to > puzzle->columns || from == to) {
        printf("Invalid move: Out of bounds or same column.\n");
        return 0;
    }

    from--;
    to--;

    int fromRow = -1;
    for (int i = 0; i < puzzle->rows; i++) {
        if (puzzle->field[i][from] != BLANK) {
            fromRow = i;
            break;
        }
    }
    if (fromRow == -1) {
        printf("Origin column is empty.\n");
        return 0;
    }

    int toRow = puzzle->rows - 1;
    for (int i = puzzle->rows - 1; i >= 0; i--) {
        if (puzzle->field[i][to] == BLANK) {
            toRow = i;
            break;
        }
    }
    if (toRow < puzzle->rows - 1 && puzzle->field[toRow + 1][to] != puzzle->field[fromRow][from]) {
        printf("Colors do not match.\n");
        return 0;
    }

    puzzle->field[toRow][to] = puzzle->field[fromRow][from];
    puzzle->field[fromRow][from] = BLANK;
    return 1;
}

int randomIndex(int max) {
    return rand() % max;
}

int randomRange(int min, int max) {
    return min + rand() % (max - min);
}
