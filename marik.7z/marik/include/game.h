#ifndef GAME_H
#define GAME_H

typedef struct Game Game;

struct Game {
    void (*initialize)(Game* game);
    void (*run)(Game* game);
};

void initializeGame(Game* game);
void runGame(Game* game);

#endif
