﻿#ifndef CONNECT4_H
#define CONNECT4_H

#include "game.h"

#define BLANK '.'
#define PLAYER_1 'X'
#define PLAYER_2 'O'
#define STRIKE 4

typedef struct {
    Game game;
    int rows;
    int cols;
    char** board;
    char currentPlayer;
} Connect4;

void initializeConnect4(Connect4* game, int rows, int cols);
void runConnect4(Connect4* game);

#endif 
