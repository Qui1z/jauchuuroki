#ifndef BALL_SORT_PUZZLE_H
#define BALL_SORT_PUZZLE_H

#define BLANK '.'
#define EMPTY_COLUMNS 2
#define PALETTE_COUNT 7
#define SYMBOLS_ORIGIN '#'

typedef struct {
    int rows;
    int columns;
    char** field;
    int* emptyColumns;
    int emptyColumnsCount;
} BallSortPuzzle;

void initializeBallSortPuzzle(BallSortPuzzle* puzzle, int rows, int columns);
void freeBallSortPuzzle(BallSortPuzzle* puzzle);
void generateField(BallSortPuzzle* puzzle);
void printField(const BallSortPuzzle* puzzle);
int checkWin(const BallSortPuzzle* puzzle);
int moveBall(BallSortPuzzle* puzzle, int from, int to);

int randomIndex(int max);
int randomRange(int min, int max);

#endif
