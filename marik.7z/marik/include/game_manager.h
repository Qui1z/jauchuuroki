#ifndef GAME_MANAGER_H
#define GAME_MANAGER_H

#include <vector>
#include <memory>
#include "game.h"

class GameManager {
private:
    std::vector<std::unique_ptr<Game>> games;

public:
    void addGame(std::unique_ptr<Game> game);
    void run();
};

#endif
